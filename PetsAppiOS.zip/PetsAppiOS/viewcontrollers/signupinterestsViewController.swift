//
//  signupinterestsViewController.swift
//  PetsApp
//
//  Created by MacBook Pro on 3/31/21.
//  Copyright © 2021 MacBook Pro. All rights reserved.
//

import UIKit

class signupinterestsViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view.
    }
    
    override func viewWillAppear(_ animated: Bool)
           {
          navigationController?.setNavigationBarHidden(true, animated: animated)

            }
          override func viewWillDisappear(_ animated: Bool) {
              super.viewWillDisappear(animated)
              navigationController?.setNavigationBarHidden(false, animated: animated)
          }
  
}
extension signupinterestsViewController: UICollectionViewDelegate, UICollectionViewDataSource
{
        func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int
        {
            
            return 9
          
            }
func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
         
   
     let cell = (collectionView.dequeueReusableCell(withReuseIdentifier: "YourInterests", for: indexPath)) as? YourInterestsCollectionViewCell
    
    
    
    cell!.contentView.layer.cornerRadius = 20
    cell!.contentView.layer.borderWidth = 1.0

    cell!.contentView.layer.borderColor = UIColor.red.cgColor
    cell!.contentView.layer.masksToBounds = true

    //cell!.layer.shadowColor = UIColor.gray.cgColor
   // cell!.layer.shadowOffset = CGSize(width: 2, height: 2.0)
   // cell!.layer.shadowRadius = 5.0
   // cell!.layer.shadowOpacity = 0.4
   // cell!.layer.masksToBounds = false
   // cell!.layer.shadowPath = UIBezierPath(roundedRect:cell!.bounds, cornerRadius:cell!.contentView.layer.cornerRadius).cgPath

    
        
    return cell!;

    }
   // }
    }

    extension signupinterestsViewController: UICollectionViewDelegateFlowLayout
    {
        func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize
        {
     
        let size = (collectionView.frame.width/3)-15
        return CGSize(width: size, height: 40 )
        }
}
       
        
  //  }
