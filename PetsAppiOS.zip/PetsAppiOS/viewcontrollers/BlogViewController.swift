//
//  BlogViewController.swift
//  PetsApp
//
//  Created by MacBook Pro on 3/29/21.
//  Copyright © 2021 MacBook Pro. All rights reserved.
//

import UIKit

class BlogViewController: UIViewController {
    var arrOfBlogs:[Get_Blogs] = [Get_Blogs]()
    var index = -1
    @IBOutlet weak var petsImage: UIButton!
    override func viewDidLoad() {
        super.viewDidLoad()
        
        let Blog_Obj = Get_Blogs()
        arrOfBlogs = Blog_Obj.get_Blogs()
        print(arrOfBlogs)
        

        petsImage.layer.cornerRadius = 9
        petsImage.clipsToBounds = true
    self.navigationController?.navigationBar.setBackgroundImage(UIImage(named:"Header"), for: .default)
            
            
        self.navigationController?.navigationBar.shadowImage = UIImage()
        // Do any additional setup after loading the view.
    }

}
extension BlogViewController: UICollectionViewDelegate, UICollectionViewDataSource {
        func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int
        {
            
            return arrOfBlogs.count
          
            }
func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
         
   
     let cell = (collectionView.dequeueReusableCell(withReuseIdentifier: "blog", for: indexPath)) as? BlogCollectionViewCell
    
    cell?.blog_title.text = arrOfBlogs[indexPath.row].title
    cell?.created_Date.text = arrOfBlogs[indexPath.row].createdDate
    cell?.blog_Author.text = "Author : "+arrOfBlogs[indexPath.row].firstName+" "+arrOfBlogs[indexPath.row].lastName
    

    
    cell!.contentView.layer.cornerRadius = 35
    cell!.contentView.layer.borderWidth = 1.0

    cell!.contentView.layer.borderColor = UIColor.clear.cgColor
    cell!.contentView.layer.masksToBounds = true

    cell!.layer.shadowColor = UIColor.gray.cgColor
    cell!.layer.shadowOffset = CGSize(width: 2, height: 2.0)
    cell!.layer.shadowRadius = 5.0
    cell!.layer.shadowOpacity = 0.4
    cell!.layer.masksToBounds = false
    cell!.layer.shadowPath = UIBezierPath(roundedRect:cell!.bounds, cornerRadius:cell!.contentView.layer.cornerRadius).cgPath

    
        
    return cell!;

    }
   // }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath)
    {
        index = indexPath.row
        
    let story: UIStoryboard = UIStoryboard(name: "pettsDetails", bundle: nil)

        let vc = (story.instantiateViewController(withIdentifier: "petsdetails") as? petsdetailViewController)!
    
        vc.index = index
        vc.arrOfBlogs = arrOfBlogs
    self.navigationController?.pushViewController(vc, animated: true)
    }
    }

    extension BlogViewController: UICollectionViewDelegateFlowLayout
    {
        func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize
        {
     
        let size = (collectionView.frame.width)
        return CGSize(width: size, height: 170 )
        }
}
       
        
  //  }
