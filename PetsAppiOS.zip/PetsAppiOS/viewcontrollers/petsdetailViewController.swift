//
//  petsdetailViewController.swift
//  PetsApp
//
//  Created by MacBook Pro on 3/23/21.
//  Copyright © 2021 MacBook Pro. All rights reserved.
//

import UIKit
import MapKit
import CoreLocation
class petsdetailViewController: UIViewController,CLLocationManagerDelegate,MKMapViewDelegate {
    @IBOutlet weak var Description: UILabel!
    
    @IBOutlet weak var Location: UILabel!
    @IBOutlet weak var breed: UILabel!
    
    @IBOutlet weak var Date: UILabel!
    
    @IBOutlet weak var category: UILabel!
    
    
    @IBOutlet weak var origin: UILabel!
    
    @IBOutlet weak var titleName: UILabel!
    
    var arrOfBlogs:[Get_Blogs] = [Get_Blogs]()
    var index : Int!
    @IBOutlet weak var callView: UIView!
    @IBOutlet weak var petsTypeCollection: UICollectionView!
    //Rectangle 226
              var location:CLLocation?
              let locationManger = CLLocationManager()
              var latitude  : Double?
              var longitude : Double?
    @IBOutlet weak var mapView: MKMapView!
    override func viewDidLoad() {
        super.viewDidLoad()
        Location.text = "Location "+": "+arrOfBlogs[index].address
        Description.text = arrOfBlogs[index].description
        titleName.text = arrOfBlogs[index].title
        Date.text = "Date "+": "+arrOfBlogs[index].createdDate
        category.text = "Category "+": "+arrOfBlogs[index].category
        breed.isHidden = true
        origin.isHidden = true
        mapView.layer.cornerRadius=20
        mapView.clipsToBounds=true
        callView.isHidden = true
        LocationAuth()
              
        startLocationManager()
    self.navigationController?.navigationBar.setBackgroundImage(UIImage(named:"Rectangle 226"), for: .default)
        
        self.navigationController?.navigationBar.shadowImage = UIImage()
        

        // Do any additional setup after loading the view.
    }
    
    
    @IBAction func backbtn(_ sender: Any)
    {
    self.navigationController?.navigationBar.setBackgroundImage(UIImage(named:"Header"), for: .default)
            
            
        self.navigationController?.navigationBar.shadowImage = UIImage()
        navigationController?.popViewController(animated: true)
    }
    

    @IBAction func reportAndSharebtn(_ sender: Any)
    {
        let storyboard = UIStoryboard(name:"pettsDetails", bundle: nil)
           let destinationVC = storyboard.instantiateViewController(withIdentifier: "reportAndshareView") as! ReportAndShareViewController
         
               destinationVC.modalPresentationStyle = .overCurrentContext
               destinationVC.modalTransitionStyle = .crossDissolve
               self.present(destinationVC,animated: false,completion: nil)
        
    }
    
    @IBAction func callbtn(_ sender: Any)
    {
        if callView.isHidden == true
        {
        callView.isHidden = false
        }
        else {
            callView.isHidden = true

        }

    }
    @IBAction func telephone(_ sender: Any)
       {
          // telephone.isSelected=true
           let alertController = UIAlertController(title:"Do you want", message: "to start a voice call ?", preferredStyle: .alert)
           
           let OKAction = UIAlertAction(title: "OK", style: .default) { (action:UIAlertAction!) in
            let url: NSURL = URL(string: "TEL://"+self.arrOfBlogs[self.index].phone)! as NSURL
               UIApplication.shared.open(url as URL, options: [:], completionHandler: nil)
               
               print("Ok button tapped");
              // self.telephone.isSelected=false
               
           }
           alertController.addAction(OKAction)
           
           let cancelAction = UIAlertAction(title: "Cancel", style: .cancel) { (action:UIAlertAction!) in
               print("Cancel button tapped");
             //  self.telephone.isSelected=false
               
           }
           alertController.addAction(cancelAction)
           
           self.present(alertController, animated: true, completion:nil)
           
       }
    
    func LocationAuth()
             {
             let authStatus = CLLocationManager.authorizationStatus()
             if authStatus == .notDetermined {
             locationManger.requestWhenInUseAuthorization()
                 }
                 
                 if authStatus == .denied || authStatus == .restricted {
                     openLocationSetting()
                 }
                 
             }
             
             func openLocationSetting()
             {
                 let alertController = UIAlertController(title: NSLocalizedString("Failure is happened ", comment: ""), message: NSLocalizedString("Active your Location Service Or Check the Internet Connection Or restart your Device to reactive the InterNet configuration Or go to Rest Network settings ", comment: ""), preferredStyle: .alert)
                 
                 let cancelAction = UIAlertAction(title: NSLocalizedString("Cancel", comment: ""), style: .cancel, handler: nil)
                 let settingsAction = UIAlertAction(title: NSLocalizedString("Settings", comment: ""), style: .default) { (UIAlertAction) in
                   UIApplication.shared.open(NSURL(string: UIApplication.openSettingsURLString)! as URL,options: [:], completionHandler: nil)
                     
                 }
                 
                 alertController.addAction(cancelAction)
                 alertController.addAction(settingsAction)
                 self.present(alertController, animated: true, completion: nil)
                 
             }
           @objc func startLocationManager() {
              if CLLocationManager.locationServicesEnabled() {
               locationManger.delegate=self
               locationManger.desiredAccuracy=kCLLocationAccuracyBest
               locationManger.startUpdatingLocation()
             //  locationManager.de = kCLLocationAccuracyBest
               //locationManager.startUpdatingLocation()
              }
              }
           func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
                   location = locations.last
               
               let center = CLLocationCoordinate2D(latitude: location!.coordinate.latitude, longitude: location!.coordinate.longitude)
                   let region = MKCoordinateRegion(center: center, span: MKCoordinateSpan(latitudeDelta: 0.01, longitudeDelta: 0.01))
                   self.mapView.setRegion(region, animated: true)
               
                   print("current location latitude \((location?.coordinate.latitude)!) and longitude \((location?.coordinate.longitude)!)")
                  
                  self.latitude = location?.coordinate.latitude
                  self.longitude = location?.coordinate.longitude
               print(self.longitude!)
                  self.locationManger.startUpdatingLocation()
           }
    }




extension petsdetailViewController: UICollectionViewDelegate, UICollectionViewDataSource {
        func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
            if collectionView == petsTypeCollection
            {
            return 5
            }
            else
            {
           return 1
            }
            }
           
        
       
func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
         
      //hena
    if collectionView == petsTypeCollection
               {
    let cell = (collectionView.dequeueReusableCell(withReuseIdentifier: "petTypes", for: indexPath) as? PetsTypewCollectionViewCell)!
    
  cell.layer.cornerRadius=10
       cell.dogType.layer.cornerRadius=10
       cell.dogType.clipsToBounds=true
       cell.clipsToBounds=true
    
   // cell.dogType.layer.cornerRadius = 5
  //  cell.dogType.layer.masksToBounds = true
    
   //cell.dogType.clipsToBounds = true;

    //cell.dogType.layer.cornerRadius = 10;
    return cell;
    }
    else
    {
        let cell = ((collectionView.dequeueReusableCell(withReuseIdentifier: "SellerName", for: indexPath)) as? UserCellCollectionViewCell)!
     
        cell.User_Name.text = arrOfBlogs[index].firstName+" "+arrOfBlogs[index].lastName
        
        cell.user_mail.text = arrOfBlogs[index].email
        
        cell.user_Phone.text = arrOfBlogs[index].phone
        
        return cell;

    }
    }
    }

    extension petsdetailViewController: UICollectionViewDelegateFlowLayout
    {
        func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize
        {
       if collectionView == petsTypeCollection
                     {
            let size = (collectionView.bounds.width/4)-5
                        return CGSize(width: size, height: collectionView.frame.height )
        }
      //  }
        else
        {
        let size = (collectionView.frame.width)
        return CGSize(width: size, height: 95 )
        }
      
        }
        
    }


