//
//  FilterViewController.swift
//  PetsApp
//
//  Created by MacBook Pro on 3/27/21.
//  Copyright © 2021 MacBook Pro. All rights reserved.
//

import UIKit
import MapKit
import CoreLocation
class FilterViewController: UIViewController,CLLocationManagerDelegate,MKMapViewDelegate {

    @IBOutlet weak var chooseLocation: UIButton!
    @IBOutlet weak var searchbtn: UIButton!
    
    @IBOutlet weak var AllCategories: UIButton!
    @IBOutlet weak var mapView: MKMapView!
    
    var location:CLLocation?
                       let locationManger = CLLocationManager()
                       var latitude  : Double?
                       var longitude : Double?

    override func viewDidLoad() {
        
       
        
        LocationAuth()
              
        startLocationManager()
        super.viewDidLoad()
        searchbtn.layer.cornerRadius = 10
        searchbtn.layer.masksToBounds = false

        searchbtn.layer.shadowColor = UIColor.darkGray.cgColor
        searchbtn.layer.shadowOffset = CGSize(width: 2.0, height: 2.0)
        searchbtn.layer.shadowOpacity = 0.4
        searchbtn.layer.shadowRadius = 5.0
        
        
        
        chooseLocation.layer.cornerRadius = 10
             chooseLocation.layer.masksToBounds = false

             chooseLocation.layer.shadowColor = UIColor.darkGray.cgColor
             chooseLocation.layer.shadowOffset = CGSize(width: 2.0, height: 2.0)
             chooseLocation.layer.shadowOpacity = 0.4
             chooseLocation.layer.shadowRadius = 5.0
        
        
        
        
        
        
           AllCategories.layer.cornerRadius = 10
                AllCategories.layer.masksToBounds = false

                AllCategories.layer.shadowColor = UIColor.darkGray.cgColor
                AllCategories.layer.shadowOffset = CGSize(width: 2.0, height: 2.0)
                AllCategories.layer.shadowOpacity = 0.4
                AllCategories.layer.shadowRadius = 5.0
             
        
        
self.navigationController?.navigationBar.setBackgroundImage(UIImage(named:"Rectangle 241"), for: .default)
        
        self.navigationController?.navigationBar.tintColor = UIColor.white

        let textAttributes = [NSAttributedString.Key.foregroundColor:UIColor.white]
        
      
        navigationController?.navigationBar.titleTextAttributes = textAttributes

    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */
    func LocationAuth()
                {
                let authStatus = CLLocationManager.authorizationStatus()
                if authStatus == .notDetermined {
                locationManger.requestWhenInUseAuthorization()
                    }
                    
                    if authStatus == .denied || authStatus == .restricted {
                        openLocationSetting()
                    }
                    
                }
                
                func openLocationSetting()
                {
                    let alertController = UIAlertController(title: NSLocalizedString("Failure is happened ", comment: ""), message: NSLocalizedString("Active your Location Service Or Check the Internet Connection Or restart your Device to reactive the InterNet configuration Or go to Rest Network settings ", comment: ""), preferredStyle: .alert)
                    
                    let cancelAction = UIAlertAction(title: NSLocalizedString("Cancel", comment: ""), style: .cancel, handler: nil)
                    let settingsAction = UIAlertAction(title: NSLocalizedString("Settings", comment: ""), style: .default) { (UIAlertAction) in
                      UIApplication.shared.open(NSURL(string: UIApplication.openSettingsURLString)! as URL,options: [:], completionHandler: nil)
                        
                    }
                    
                    alertController.addAction(cancelAction)
                    alertController.addAction(settingsAction)
                    self.present(alertController, animated: true, completion: nil)
                    
                }
              @objc func startLocationManager() {
                 if CLLocationManager.locationServicesEnabled() {
                  locationManger.delegate=self
                  locationManger.desiredAccuracy=kCLLocationAccuracyBest
                  locationManger.startUpdatingLocation()
                //  locationManager.de = kCLLocationAccuracyBest
                  //locationManager.startUpdatingLocation()
                 }
                 }
              func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
                      location = locations.last
                  
                  let center = CLLocationCoordinate2D(latitude: location!.coordinate.latitude, longitude: location!.coordinate.longitude)
                      let region = MKCoordinateRegion(center: center, span: MKCoordinateSpan(latitudeDelta: 0.01, longitudeDelta: 0.01))
                      self.mapView.setRegion(region, animated: true)
                  
                      print("current location latitude \((location?.coordinate.latitude)!) and longitude \((location?.coordinate.longitude)!)")
                     
                     self.latitude = location?.coordinate.latitude
                     self.longitude = location?.coordinate.longitude
                  print(self.longitude!)
                     self.locationManger.startUpdatingLocation()
              }
}
