//
//  ClinicViewController.swift
//  PetsApp
//
//  Created by MacBook Pro on 3/25/21.
//  Copyright © 2021 MacBook Pro. All rights reserved.
//

import UIKit

class ClinicViewController: UIViewController {
    @IBOutlet weak var petImage: UIButton!
    
    @IBOutlet weak var hospital: UIButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        hospital.layer.borderWidth = 5
        hospital.layer.borderColor = UIColor(red: 255/255, green: 85/255, blue: 81/255, alpha: 1.0).cgColor
        
        hospital.layer.cornerRadius =  (hospital.frame.size.width)/2
                    hospital.clipsToBounds = true
        petImage.layer.cornerRadius = 9
              petImage.clipsToBounds = true
              self.navigationController?.navigationBar.setBackgroundImage(UIImage(named:"Rectangle 241"), for: .default)
              
              self.navigationController?.navigationBar.shadowImage = UIImage()


        // Do any additional setup after loading the view.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
