//
//  ChatViewController.swift
//  PetsApp
//
//  Created by MacBook Pro on 3/31/21.
//  Copyright © 2021 MacBook Pro. All rights reserved.
//

import UIKit
import MessageKit
class ChatViewController: MessagesViewController,MessagesDataSource, MessagesLayoutDelegate, MessagesDisplayDelegate
{
    
    @IBOutlet weak var messageCollection: MessagesCollectionView!
    let messages  = ["hello","fine Thanks","ok","will be okey"]
   // private var messages: [Message] = []

    override func viewDidLoad() {
        super.viewDidLoad()
        
        messagesCollectionView.messagesDataSource = self
           messagesCollectionView.messagesLayoutDelegate = self
           messagesCollectionView.messagesDisplayDelegate = self
    //    messageCollection.delegate = self as? UICollectionViewDelegate
       // messageCollection.dataSource = self as? UICollectionViewDataSource



    }
    
    func currentSender() -> SenderType {
        /*   if let sender = self
           {
               return sender
           }*/

           fatalError("Self Sender is nil, email should be cached")
       }

    
    
       func messageForItem(at indexPath: IndexPath, in messagesCollectionView: MessagesCollectionView) -> MessageType {
           return (messages[indexPath.section])
       }

       func numberOfSections(in messagesCollectionView: MessagesCollectionView) -> Int {
           return messages.count
       }

       func numberOfItems(inSection section: Int, in messagesCollectionView: MessagesCollectionView) -> Int {
           return 1
       }
       

       func backgroundColor(for message: MessageType, at indexPath: IndexPath, in messagesCollectionView: MessagesCollectionView) -> UIColor {
           let sender = message.sender
         

           return .secondarySystemBackground
       }

      
    
}

