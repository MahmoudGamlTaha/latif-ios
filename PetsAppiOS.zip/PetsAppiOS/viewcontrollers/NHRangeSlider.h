//
//  NHRangeSlider.h
//  NHRangeSlider
//
//  Created by Hung on 18/12/16.
//  Copyright © 2016 Hung. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for NHRangeSlider.
FOUNDATION_EXPORT double NHRangeSliderVersionNumber;

//! Project version string for NHRangeSlider.
FOUNDATION_EXPORT const unsigned char NHRangeSliderVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <NHRangeSlider/PublicHeader.h>


