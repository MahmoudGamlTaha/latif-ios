//
//  SubscribeViewController.swift
//  PetsApp
//
//  Created by MacBook Pro on 3/27/21.
//  Copyright © 2021 MacBook Pro. All rights reserved.
//

import UIKit

class SubscribeViewController: UIViewController {
    let arrOfPackageTypeText = ["Package #1","Package #2","Package #3"]
    
    
override func viewDidLoad()
{
super.viewDidLoad()
        
self.navigationController?.navigationBar.setBackgroundImage(UIImage(named:"Header"), for: .default)
    
    
self.navigationController?.navigationBar.shadowImage = UIImage()

                

    }
}
extension SubscribeViewController: UICollectionViewDelegate, UICollectionViewDataSource {
        func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int
        {
            
            return 3
          
            }
func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
         
   
     let cell = (collectionView.dequeueReusableCell(withReuseIdentifier: "subscribe", for: indexPath)) as? SubscribeCollectionViewCell
    
    
    cell?.packageName.text = arrOfPackageTypeText[indexPath.row]
    
    cell!.contentView.layer.cornerRadius = 35
    cell!.contentView.layer.borderWidth = 1.0

    cell!.contentView.layer.borderColor = UIColor.clear.cgColor
    cell!.contentView.layer.masksToBounds = true

    cell!.layer.shadowColor = UIColor.gray.cgColor
    cell!.layer.shadowOffset = CGSize(width: 2, height: 2.0)
    cell!.layer.shadowRadius = 5.0
    cell!.layer.shadowOpacity = 0.4
    cell!.layer.masksToBounds = false
    cell!.layer.shadowPath = UIBezierPath(roundedRect:cell!.bounds, cornerRadius:cell!.contentView.layer.cornerRadius).cgPath

    
        
    return cell!;

    }
   // }
    }

    extension SubscribeViewController: UICollectionViewDelegateFlowLayout
    {
        func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize
        {
     
        let size = (collectionView.frame.width-2)
        return CGSize(width: size, height: 151 )
        }
}
       
        
  //  }
