//
//  SignInViewController.swift
//  PetsApp
//
//  Created by MacBook Pro on 3/23/21.
//  Copyright © 2021 MacBook Pro. All rights reserved.
//

import UIKit

class SignInViewController: UIViewController {

    @IBOutlet weak var logoimg: UIImageView!
    override func viewDidLoad() {
        super.viewDidLoad()
        view.addSubview(logoimg)

    }
    override func viewWillAppear(_ animated: Bool)
     {
    navigationController?.setNavigationBarHidden(true, animated: animated)

      }
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        navigationController?.setNavigationBarHidden(false, animated: animated)
    }
   
    @IBAction func navtosignup(_ sender: Any)
    {
        let story: UIStoryboard = UIStoryboard(name: "Main", bundle: nil)

          let vc = story.instantiateViewController(withIdentifier: "navControllersignup")
                  
          self.navigationController?.pushViewController(vc, animated: true)
    }
    
    
}
