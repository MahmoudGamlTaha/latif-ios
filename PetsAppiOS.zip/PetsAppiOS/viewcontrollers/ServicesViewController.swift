//
//  ServicesViewController.swift
//  PetsApp
//
//  Created by MacBook Pro on 3/24/21.
//  Copyright © 2021 MacBook Pro. All rights reserved.
//

import UIKit

class ServicesViewController: UIViewController {

    @IBOutlet weak var servicebtn: UIButton!
    @IBOutlet weak var petImage: UIButton!
    override func viewDidLoad() {
        super.viewDidLoad()
    
        petImage.layer.cornerRadius = 9
        petImage.clipsToBounds = true
        self.navigationController?.navigationBar.setBackgroundImage(UIImage(named:"Header"), for: .default)
        
        self.navigationController?.navigationBar.shadowImage = UIImage()
        
        
        servicebtn.layer.borderWidth = 5
        servicebtn.layer.borderColor = UIColor(red: 255/255, green: 85/255, blue: 81/255, alpha: 1.0).cgColor
        
        servicebtn.layer.cornerRadius =  (servicebtn.frame.size.width)/2
                    servicebtn.clipsToBounds = true

    }
    

    @IBAction func gotoHospital(_ sender: Any)
    {
    let story: UIStoryboard = UIStoryboard(name: "clinic", bundle: nil)

          let vc = story.instantiateViewController(withIdentifier: "navClinic")
                  
          self.navigationController?.pushViewController(vc, animated: true)
    }
    

}
