//
//  SideMenuViewController.swift
//  Floria_Merchant
//
//  Created by macbookpro on 7/10/19.
//  Copyright © 2019 macbookpro. All rights reserved.
//

import UIKit

class SideMenuViewController: UIViewController,UITableViewDataSource,UITableViewDelegate {
    
    @IBOutlet var table: UITableView!
    let arrOfDataText = ["Pets","Items","Services","Blog","Setting"]
  
    
    @IBOutlet weak var topView: UIView!
    override func viewWillAppear(_ animated: Bool)
        {
        navigationController?.setNavigationBarHidden(true, animated: animated)
        }
    override func viewWillDisappear(_ animated: Bool)
    {
        super.viewWillDisappear(animated)
        navigationController?.setNavigationBarHidden(false, animated: animated)
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return arrOfDataText.count
        }
  
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell
    {
        let cell = tableView.dequeueReusableCell(withIdentifier: "sideMenuCell", for: indexPath) as? SideMenuTableViewCell
      cell?.layer.frame.size.width = (table?.layer.frame.size.width)!
        
        cell?.backgroundColor = .clear

        cell?.TextData.text = arrOfDataText[indexPath.row]
        
        
      //  @IBOutlet weak var TextData: UILabel!
   // cell?.typename.text=arrOfDataText[indexPath.row]
        return cell!;
        
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        
      
        
    }
func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat
{
return 87
    
}

override func viewDidLoad()
{
    topView.clipsToBounds = true
    topView.layer.cornerRadius = 40
    topView.layer.maskedCorners = [.layerMaxXMinYCorner]
    
    
   table.clipsToBounds = true
    table.layer.cornerRadius = 40
    table.layer.maskedCorners = [.layerMaxXMaxYCorner]
      
    
view.backgroundColor = .clear
super.viewDidLoad()
}
}
