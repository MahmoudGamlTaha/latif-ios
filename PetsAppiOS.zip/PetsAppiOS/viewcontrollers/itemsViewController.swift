//
//  itemsViewController.swift
//  PetsApp
//
//  Created by MacBook Pro on 3/29/21.
//  Copyright © 2021 MacBook Pro. All rights reserved.
//

import UIKit

class itemsViewController: UIViewController {

    @IBOutlet weak var petbtn: UIButton!

    @IBOutlet weak var petsCollectionview: UICollectionView!
    var index = -1

    var arrofpetstext = ["Dog","Cat","Hamster","Fish"]
    var arrOfPetsImages = [UIImage(named: "dog"),UIImage(named: "cat"),UIImage(named: "hamster"),UIImage(named: "fish")]
     var arrOfSelectedPetsImages = [UIImage(named: "dog_yellow"),UIImage(named: "cat"),UIImage(named: "hamster"),UIImage(named: "fish")]
    override func viewDidLoad() {
        super.viewDidLoad()
        self.navigationController?.navigationBar.setBackgroundImage(UIImage(named:"Header"), for: .default)
               
               self.navigationController?.navigationBar.shadowImage = UIImage()
        petbtn.layer.borderWidth = 5
        petbtn.layer.borderColor = UIColor(red: 255/255, green: 85/255, blue: 81/255, alpha: 1.0).cgColor
              
        petbtn.layer.cornerRadius =  (petbtn.frame.size.width)/2
                          petbtn.clipsToBounds = true

        // Do any additional setup after loading the view.
    }
    

  

}
 extension itemsViewController: UICollectionViewDelegate, UICollectionViewDataSource {
        func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
         return 4;
        }
        
        func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
         
         if collectionView == petsCollectionview
         {
            
     let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "petsCollection", for: indexPath) as? petsCollectionViewCell
         
         
         cell?.petText.text = arrofpetstext[indexPath.row]
          cell?.petButton.layer.borderWidth = 1
         cell?.petButton.layer.borderColor = UIColor.lightGray.cgColor
         cell?.petButton.layer.cornerRadius =  (cell?.petButton.frame.size.width)!/2
          cell?.petButton.clipsToBounds = true
         //arrOfSelectedPetsImages
         //
         if index == indexPath.row
         {
             cell?.petImage.image = arrOfSelectedPetsImages[indexPath.row]

             cell?.topConstriants.constant = 40
             cell?.petButton.isHidden = false
             cell?.petText.textColor =  UIColor(red: 247/255, green: 178/255, blue: 67/255, alpha: 1.0)
         }
        
         else
         {
             cell?.petImage.image = arrOfPetsImages[indexPath.row]

             cell?.topConstriants.constant = 8
             cell?.petButton.isHidden = true
             cell?.petText.textColor =  UIColor(red: 235/255, green: 235/255, blue: 235/255, alpha: 1.0)


         }
         return cell!;
            }
         else {
            let cell = (collectionView.dequeueReusableCell(withReuseIdentifier: "items", for: indexPath)) as? itemsCollectionViewCell
               
               cell!.contentView.layer.cornerRadius = 35
               cell!.contentView.layer.borderWidth = 1.0

               cell!.contentView.layer.borderColor = UIColor.clear.cgColor
               cell!.contentView.layer.masksToBounds = true

               cell!.layer.shadowColor = UIColor.gray.cgColor
               cell!.layer.shadowOffset = CGSize(width: 2, height: 2.0)
               cell!.layer.shadowRadius = 5.0
               cell!.layer.shadowOpacity = 0.4
               cell!.layer.masksToBounds = false
               cell!.layer.shadowPath = UIBezierPath(roundedRect:cell!.bounds, cornerRadius:cell!.contentView.layer.cornerRadius).cgPath

               return cell!;
            }
          
    }
     func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath)
     {
        if collectionView == petsCollectionview
        {
         index = indexPath.row
         collectionView.reloadData()
        }
     }
 }
 extension itemsViewController : UICollectionViewDelegateFlowLayout {
       
     
       func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        
        
          if collectionView == petsCollectionview
          {
           let size = collectionView.frame.size
           return CGSize(width: 83, height: size.height)
        }
        else
          {
            let size = (collectionView.frame.width-2)
            return CGSize(width: size, height: 120 )
        }
       }
       
    
       
       
       
       
   }

