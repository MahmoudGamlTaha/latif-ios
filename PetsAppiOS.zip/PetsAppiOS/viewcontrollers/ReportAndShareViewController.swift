//
//  ReportAndShareViewController.swift
//  PetsApp
//
//  Created by MacBook Pro on 3/26/21.
//  Copyright © 2021 MacBook Pro. All rights reserved.
//

import UIKit

class ReportAndShareViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

    }
    
    @IBAction func reportAd(_ sender: Any)
    {
        let storyboard = UIStoryboard(name:"pettsDetails", bundle: nil)
        let destinationVC = storyboard.instantiateViewController(withIdentifier: "reportAdView") as! ReportAdViewController
               
        destinationVC.modalPresentationStyle = .overCurrentContext
        destinationVC.modalTransitionStyle = .crossDissolve
        self.present(destinationVC,animated: false,completion: nil)
    
    }
    
   

}
