//
//  BlogCollectionViewCell.swift
//  PetsApp
//
//  Created by MacBook Pro on 3/29/21.
//  Copyright © 2021 MacBook Pro. All rights reserved.
//

import UIKit

class BlogCollectionViewCell: UICollectionViewCell
{
    @IBOutlet weak var blog_title: UILabel!
    
    @IBOutlet weak var blog_Author: UILabel!
    
    @IBOutlet weak var created_Date: UILabel!
    
}
