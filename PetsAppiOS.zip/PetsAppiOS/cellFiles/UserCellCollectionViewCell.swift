//
//  UserCellCollectionViewCell.swift
//  PetsApp
//
//  Created by MacBook Pro on 4/5/21.
//  Copyright © 2021 MacBook Pro. All rights reserved.
//

import UIKit

class UserCellCollectionViewCell: UICollectionViewCell {
    
    @IBOutlet weak var User_Name: UILabel!
    
    @IBOutlet weak var user_mail: UILabel!
    
    @IBOutlet weak var user_Phone: UILabel!
    
}
