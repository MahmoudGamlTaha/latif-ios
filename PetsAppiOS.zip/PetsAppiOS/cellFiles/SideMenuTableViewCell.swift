//
//  SideMenuTableViewCell.swift
//  Go-Free
//
//  Created by MacBook Pro on 2/2/21.
//  Copyright © 2021 MacBook Pro. All rights reserved.
//

import UIKit

class SideMenuTableViewCell: UITableViewCell {

    @IBOutlet weak var imageData: UIImageView!
    
    @IBOutlet weak var TextData: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
