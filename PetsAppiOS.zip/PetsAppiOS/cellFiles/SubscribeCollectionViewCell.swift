//
//  SubscribeCollectionViewCell.swift
//  PetsApp
//
//  Created by MacBook Pro on 3/27/21.
//  Copyright © 2021 MacBook Pro. All rights reserved.
//

import UIKit

class SubscribeCollectionViewCell: UICollectionViewCell
{
    
    @IBOutlet weak var packageName: UILabel!
    
    @IBOutlet weak var backgroundImage: UIImageView!
    
}
