//
//  petsCollectionViewCell.swift
//  PetsApp
//
//  Created by MacBook Pro on 3/22/21.
//  Copyright © 2021 MacBook Pro. All rights reserved.
//

import UIKit

class petsCollectionViewCell: UICollectionViewCell {
    
    @IBOutlet weak var petButton: UIButton!
    
    @IBOutlet weak var petText: UILabel!
    @IBOutlet weak var petImage: UIImageView!
    @IBOutlet weak var topConstriants: NSLayoutConstraint!
    
}
