//
//  itemsCollectionViewCell.swift
//  PetsApp
//
//  Created by MacBook Pro on 3/29/21.
//  Copyright © 2021 MacBook Pro. All rights reserved.
//

import UIKit

class itemsCollectionViewCell: UICollectionViewCell {
    
}
