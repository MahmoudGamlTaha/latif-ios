//
//  SignUpPrivacyViewController.swift
//  PetsApp
//
//  Created by MacBook Pro on 3/31/21.
//  Copyright © 2021 MacBook Pro. All rights reserved.
//

import UIKit

class SignUpPrivacyViewController: UIViewController {

    @IBOutlet weak var PrivacyPolicyView: UIView!
    override func viewWillAppear(_ animated: Bool)
        {
       navigationController?.setNavigationBarHidden(true, animated: animated)

         }
       override func viewWillDisappear(_ animated: Bool) {
           super.viewWillDisappear(animated)
           navigationController?.setNavigationBarHidden(false, animated: animated)
       }

    override func viewDidLoad()
    {
        PrivacyPolicyView.layer.cornerRadius = 10
        PrivacyPolicyView.clipsToBounds = true
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
