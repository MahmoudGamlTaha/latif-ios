////
//  AppDelegate.swift
//  Messenger
//
//  Created by Afraz Siddiqui on 6/6/20.
//  Copyright © 2020 ASN GROUP LLC. All rights reserved.
//

import UIKit
import Firebase
import FBSDKCoreKit
import GoogleSignIn
@UIApplicationMain
class AppDelegate: UIResponder, UIApplicationDelegate {

    func application(
        _ application: UIApplication,
        didFinishLaunchingWithOptions launchOptions: [UIApplication.LaunchOptionsKey: Any]?
    ) -> Bool {

        FirebaseApp.configure()
        
        ApplicationDelegate.shared.application(
            application,
            didFinishLaunchingWithOptions: launchOptions
        )

        GIDSignIn.sharedInstance()?.clientID = FirebaseApp.app()?.options.clientID
        GIDSignIn.sharedInstance()?.delegate = self

        return true
    }

    func application(
        _ app: UIApplication,
        open url: URL,
        options: [UIApplication.OpenURLOptionsKey : Any] = [:]
    ) -> Bool {

        ApplicationDelegate.shared.application(
            app,
            open: url,
            sourceApplication: options[UIApplication.OpenURLOptionsKey.sourceApplication] as? String,
            annotation: options[UIApplication.OpenURLOptionsKey.annotation]
        )

        return GIDSignIn.sharedInstance().handle(url)
    }
}

// MARK: - GIDSignInDelegate

extension  AppDelegate: GIDSignInDelegate {
    func sign(_ signIn: GIDSignIn!, didSignInFor user: GIDGoogleUser!, withError error: Error!) {
        guard error == nil else {
            if let error = error {
                print("Failed to sign in with Google: \(error)")
            }
            return
        }

        guard let user = user else {
            return
        }

        print("Did sign in with Google: \(user)")

        guard let email = user.profile.email,
            let firstName = user.profile.givenName,
            let lastName = user.profile.familyName else {
                return
        }

        UserDefaults.standard.set(email, forKey: "email")
        UserDefaults.standard.set("\(firstName) \(lastName)", forKey: "name")

        DatabaseManager.shared.userExists(with: email, completion: { exists in
            if !exists {
                // insert to database
                let chatUser = ChatAppUser(firstName: firstName,
                                           lastName: lastName,
                                           emailAddress: email)
                DatabaseManager.shared.insertUser(with: chatUser, completion: { success in
                    if success {
                        // upload image

                        if user.profile.hasImage {
                            guard let url = user.profile.imageURL(withDimension: 200) else {
                                return
                            }

                            URLSession.shared.dataTask(with: url, completionHandler: { data, _, _ in
                                guard let data = data else {
                                    return
                                }

                                let filename = chatUser.profilePictureFileName
                                StorageManager.shared.uploadProfilePicture(with: data, fileName: filename, completion: { result in
                                    switch result {
                                    case .success(let downloadUrl):
                                        UserDefaults.standard.set(downloadUrl, forKey: "profile_picture_url")
                                        print(downloadUrl)
                                    case .failure(let error):
                                        print("Storage maanger error: \(error)")
                                    }
                                })
                            }).resume()
                        }


                    }
                })
            }
        })

        guard let authentication = user.authentication else {
            print("Missing auth object off of google user")
            return
        }
        let credential = GoogleAuthProvider.credential(withIDToken: authentication.idToken,
                                                       accessToken: authentication.accessToken)

        FirebaseAuth.Auth.auth().signIn(with: credential, completion: { authResult, error in
            guard authResult != nil, error == nil else {
                print("failed to log in with google credential")
                return
            }

            print("Successfully signed in with Google cred.")
            NotificationCenter.default.post(name: .didLogInNotification, object: nil)
        })
    }

    func sign(_ signIn: GIDSignIn!, didDisconnectWith user: GIDGoogleUser!, withError error: Error!) {
        print("Google user was disconnected")
    }
}


/*
 m3lomat hamah :
 1-lma bn7eb n3mel 7aga feha navigation b2dena
 bndy el title or vc.title = "" , w kman feh 7aga esmha navigationitem
 de bnkteb feha #selector l func mo3ina 3shan y segue to another vc using push view controller.
 w 3shan y3ml navigation to another view by2ol msalan
 let vc = loginviewcontroller()
 navCon.push(vc,true)
 law 3yzen nkteb layout ( viewdidlayout)
 
 //bn3mel configure ll firebase account w el google.plist w b3den bn3mel fe el app delegate import ll firebase w n3mel firebaseapp.configure
 
 //w b3den bn3mel el sign in authentecation 3shan n3mel create ll user fe el register w b3dha bn3mel firebaseAuth.signin fe el login  w fe el coversation en law firebaseAuth.current user == nil yro7 l login view
 
 //w hnro7 ll fire base el 5ana ely esmha users hnla2y el user et3mlo create
 //w b3den 3mlna create l real time database
 //w b3den bnsm7 ll data base (read w write ) w bn3mlha publish
 //w b3den bn3mel data base manger model w ely byb2a feh kol el manegment bta3et el chat as insertuser function w de by3mel feha include l first name , last name , email , password and so on 3shan yzhrly fe el database bta3y w y3mel create ll key value bta3hom as "first_name":maha
 w bynady 3la databasemanager.shared.inseruser at regiser btn w by3mel closure by3mel upload ll image mn 5lalha
 w by3mel save fe el data base 3n tare2 klmet setvalue, child w b3mel import l firebasedatabase
 
 w lma bnegy n3mel create ll facebook bnd5ol 3la facebook for developers
 w n3mel create l facebook app id
 w google bn3mel scheme ll url fe el info (resrved id fe google plist)
 //////////
 fe el converstationsview controller b2a :
 1-snap shot listenr to database
 2-snap shot meaning : read only copy of data (view of data base at some point)
 3-bgeb kol el conv 3n tare2 : DatabaseManager.shared.get All  Conv
 b2olo : database.child(email/conversations)
 w law 3yza 23mel validAuth bkteb : if firebase.Auth.currentuser==nil
 w 2dar fe el database ashof el cov exit wla la
 fe el chat viewcontrollers bzbat el message kit funcs
 w bgeb kol el messages 3n tare2 database.child(id/messages)
 w brga3 el swar w el vedio w bb3thom k url  w law 3yza 23mel send message b3mel el request da :
 database.child(conversations/messages)
 
 
 fbloginkit : fbloginkit.grapghrequest(email,firstname and so on)
 w nrag3 el data w nsivha fe data base
 
 send message :
 1- create a new conv if no conversation created before between two user
 2-create new messege id using email and other user email and date string
 3-then conversation id : "conversations"\message.messageid
 w message da object from class Message
 4-w b3den send message to conversation id from user(email to other user mail)
 5-1-upload profile pic  3n tare2 let data = image.pngdata()
 2-w b3mel upload ll data fe el storage w fe 7alet el success b3mel download url w asifo
 3-b3mel create new user :
 1- check if the user exit or not
 2- b3mel insert user:
 database.child(user.safemail).setvalue (dic of first name and last name)
 //////////////
 
 //when we send message to database :
 case text
 case image : bgeb el absolute url string
 w b3mel upload
 
 
 */
