//
//  ViewController.swift
//  PetsApp
//
//  Created by MacBook Pro on 3/22/21.
//  Copyright © 2021 MacBook Pro. All rights reserved.
//

import UIKit
import MapKit
import CoreLocation
class ViewController: UIViewController,CLLocationManagerDelegate,MKMapViewDelegate
{
    //navController
    @IBOutlet weak var petbtn: UIButton!
    @IBOutlet weak var mapView: MKMapView!
    @IBOutlet weak var headerImage: UIImageView!
    
    @IBOutlet weak var navigation: UINavigationItem!
    //dog_yellow
    let transiton = Slideintransition()

    var location:CLLocation?
      let locationManger = CLLocationManager()
      var latitude  : Double?
      var longitude : Double?
    var index = -1

    var arrofpetstext = ["Dog","Cat","Hamster","Fish"]
    var arrOfPetsImages = [UIImage(named: "cat"),UIImage(named: "dog"),UIImage(named: "hamster")]

    var arrOfpetsImages : [Get_PetsData]=[Get_PetsData]()
    
    // var arrOfSelectedPetsImages = [UIImage(named: "dog_yellow"),UIImage(named: "cat"),UIImage(named: "hamster"),UIImage(named: "fish")]
    override func viewDidLoad() {
        super.viewDidLoad()
        let obj = Get_PetsData()
        arrOfpetsImages=obj.get_PetsData()
        petbtn.layer.borderWidth = 5
        petbtn.layer.borderColor = UIColor(red: 255/255, green: 85/255, blue: 81/255, alpha: 1.0).cgColor
        
        petbtn.layer.cornerRadius =  (petbtn.frame.size.width)/2
                    petbtn.clipsToBounds = true
        mapView.delegate=self

        LocationAuth()
        
        startLocationManager()
        
     
    self.navigationController?.navigationBar.setBackgroundImage(UIImage(named:"Header"), for: .default)
        
        self.navigationController?.navigationBar.shadowImage = UIImage()
        
        
        

    }
    
    
    @IBAction func didtabSideMenue(_ sender: Any)
    {
        
   let story: UIStoryboard = UIStoryboard(name: "Main", bundle: nil)

   let menuviewcontroller = story.instantiateViewController(withIdentifier: "menuviewcontroller")as! SideMenuViewController
                      
    menuviewcontroller.modalPresentationStyle = .overCurrentContext
    menuviewcontroller.transitioningDelegate = self
    present(menuviewcontroller, animated: true)
    }
    
    func LocationAuth()
         {
         let authStatus = CLLocationManager.authorizationStatus()
         if authStatus == .notDetermined {
         locationManger.requestWhenInUseAuthorization()
             }
             
             if authStatus == .denied || authStatus == .restricted {
                 openLocationSetting()
             }
             
         }
         
         func openLocationSetting()
         {
             let alertController = UIAlertController(title: NSLocalizedString("Failure is happened ", comment: ""), message: NSLocalizedString("Active your Location Service Or Check the Internet Connection Or restart your Device to reactive the InterNet configuration Or go to Rest Network settings ", comment: ""), preferredStyle: .alert)
             
             let cancelAction = UIAlertAction(title: NSLocalizedString("Cancel", comment: ""), style: .cancel, handler: nil)
             let settingsAction = UIAlertAction(title: NSLocalizedString("Settings", comment: ""), style: .default) { (UIAlertAction) in
               UIApplication.shared.open(NSURL(string: UIApplication.openSettingsURLString)! as URL,options: [:], completionHandler: nil)
                 
             }
             
             alertController.addAction(cancelAction)
             alertController.addAction(settingsAction)
             self.present(alertController, animated: true, completion: nil)
             
         }
       @objc func startLocationManager() {
          if CLLocationManager.locationServicesEnabled() {
           locationManger.delegate=self
           locationManger.desiredAccuracy=kCLLocationAccuracyBest
           locationManger.startUpdatingLocation()
         //  locationManager.de = kCLLocationAccuracyBest
           //locationManager.startUpdatingLocation()
          }
          }
       func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
               location = locations.last
           
           let center = CLLocationCoordinate2D(latitude: location!.coordinate.latitude, longitude: location!.coordinate.longitude)
               let region = MKCoordinateRegion(center: center, span: MKCoordinateSpan(latitudeDelta: 0.01, longitudeDelta: 0.01))
               self.mapView.setRegion(region, animated: true)
           
               print("current location latitude \((location?.coordinate.latitude)!) and longitude \((location?.coordinate.longitude)!)")
              
              self.latitude = location?.coordinate.latitude
              self.longitude = location?.coordinate.longitude
           print(self.longitude!)
              self.locationManger.startUpdatingLocation()
       }
}
extension ViewController: UICollectionViewDelegate, UICollectionViewDataSource {
       func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return arrOfpetsImages.count;
       }
       
       func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        
        
           
    let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "petsCollection", for: indexPath) as? petsCollectionViewCell
        
        
        cell?.petText.text = arrOfpetsImages[indexPath.row].Pet_name
         cell?.petButton.layer.borderWidth = 1
        cell?.petButton.layer.borderColor = UIColor.lightGray.cgColor
        cell?.petButton.layer.cornerRadius =  (cell?.petButton.frame.size.width)!/2
         cell?.petButton.clipsToBounds = true
        //arrOfSelectedPetsImages
        //
        if index == indexPath.row
        {
  cell?.petImage.sd_setImage(with: URL(string:arrOfpetsImages[indexPath.row].pet_Selectedimage), placeholderImage:UIImage(named: "fish")!)
            cell?.topConstriants.constant = 40
            cell?.petButton.isHidden = false
            cell?.petText.textColor =  UIColor(red: 247/255, green: 178/255, blue: 67/255, alpha: 1.0)
        }
       
        else
        {
        if arrOfpetsImages[indexPath.row].pet_image != ""
        {
 cell?.petImage.sd_setImage(with: URL(string:arrOfpetsImages[indexPath.row].pet_image), placeholderImage:UIImage(named: "fish")!)
            }
        else
        {
            cell?.petImage.image = arrOfPetsImages[indexPath.row]
        }
            cell?.topConstriants.constant = 8
            cell?.petButton.isHidden = true
            cell?.petText.textColor =  UIColor(red: 235/255, green: 235/255, blue: 235/255, alpha: 1.0)



        }
        return cell!;
         
   }
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath)
    {
        index = indexPath.row
        collectionView.reloadData()
    }
}
   extension ViewController : UICollectionViewDelegateFlowLayout {
       
     
       func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
           let size = collectionView.frame.size
           return CGSize(width: 83, height: size.height)
       }
       
    
       
       
       
       
   }

extension ViewController: UIViewControllerTransitioningDelegate {
    func animationController(forPresented presented: UIViewController, presenting: UIViewController, source: UIViewController) -> UIViewControllerAnimatedTransitioning? {
        transiton.isPresenting = true
        return transiton
    }

    func animationController(forDismissed dismissed: UIViewController) -> UIViewControllerAnimatedTransitioning? {
        transiton.isPresenting = false
        return transiton
    }
}
