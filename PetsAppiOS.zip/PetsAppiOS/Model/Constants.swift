//
//  Constants.swift
//  Unacita_doctor
//
//  Created by MacBook Pro on 1/19/21.
//  Copyright © 2021 MacBook Pro. All rights reserved.
//

import Foundation
class constant
{

let apiURL = "https://latifapp.herokuapp.com/"
  
}
//https://latifapp.herokuapp.com/
