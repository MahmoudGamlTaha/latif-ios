//
//  LogOut_Model.swift
//  Sales Tracker
//
//  Created by MacBook Pro on 12/23/19.
//  Copyright © 2019 MacBook Pro. All rights reserved.
//

import Foundation
import Alamofire
import Alamofire_Synchronous
import SwiftyJSON
import CoreLocation
class Get_PetsData
{
var Pet_name = ""
var pet_Selectedimage : String = ""
var pet_image : String = ""


    init(Pet_name:String,pet_image:String,pet_Selectedimage:String)
{
self.Pet_name = Pet_name
self.pet_image = pet_image
self.pet_Selectedimage = pet_Selectedimage

}
init()
{
}
func get_PetsData()->[Get_PetsData]
{
var arrOfPetsData:[Get_PetsData] = [Get_PetsData]()
let api = constant()
let parameter : Parameters =
    [:]
let url = URL.init(string:"\(api.apiURL)api/public/cat-by-adType/type=1")
var request = URLRequest(url: url!)
request.httpMethod = "GET"
request.setValue("application/json", forHTTPHeaderField: "Content-Type")
//request.httpBody = try! JSONSerialization.data(withJSONObject: parameter)

let response = Alamofire.request(request)
.responseJSON()
    if let json = response.result.value
    {
    let jsonResponse : JSON = JSON(json)
    print(jsonResponse)
    var Pets_Data = [JSON]()

let response = jsonResponse["response"].dictionary!
   for n in response
   {
   if n.key == "data"
   {
   Pets_Data = n.value.arrayValue
   }
   }
    var PetsImage = ""
    var PetsName = ""
    var Pets_selectedImage = ""
    var CategoryData = [String:JSON]()
    for i in Pets_Data
        {
        CategoryData = i["category"].dictionary!
        
    for j in CategoryData
    {
    if j.key == "name"
      {
      PetsName = j.value.stringValue
      }
    if j.key == "iconSelect"
    {
    Pets_selectedImage = j.value.stringValue
    }
    
    if j.key == "icon"
    {

    if let petimage = j.value.stringValue as? String
    {
        PetsImage = petimage
        
    }
    }
        
       }
        arrOfPetsData.append(Get_PetsData(Pet_name: PetsName, pet_image: PetsImage, pet_Selectedimage: Pets_selectedImage))
        }

    }
    print(arrOfPetsData)
    return arrOfPetsData
    }
}

