//
//  LogOut_Model.swift
//  Sales Tracker
//
//  Created by MacBook Pro on 12/23/19.
//  Copyright © 2019 MacBook Pro. All rights reserved.
//

import Foundation
import Alamofire
import Alamofire_Synchronous
import SwiftyJSON
class Get_Blogs
{
var title = ""
var category = ""
var description = ""
var createdDate = ""
var ID : Int = 0
var email:String = ""
var firstName:String = ""
var lastName:String = ""
var address:String = ""
var phone:String = ""
init()
{
}
init(title:String,category:String,description:String,createdDate:String,ID:Int,email:String,firstName:String,lastName:String,address:String,phone:String)
{
self.title = title
self.category = category
self.description = description
self.createdDate = createdDate
self.ID = ID
self.email = email
self.firstName = firstName
self.lastName = lastName
self.address = address
self.phone = phone
}

func get_Blogs()->[Get_Blogs]
{

var arrOfBlogs:[Get_Blogs] = [Get_Blogs]()
let api = constant()
let parameter : Parameters =
    [:]
let url = URL.init(string:"\(api.apiURL)api/public/blogs")
var request = URLRequest(url: url!)
request.httpMethod = "GET"
request.setValue("application/json", forHTTPHeaderField: "Content-Type")

let response = Alamofire.request(request)
.responseJSON()
    if let json = response.result.value
    {
    let jsonResponse : JSON = JSON(json)
    var Blog_Data = [JSON]()
    print(jsonResponse)
    let response = jsonResponse["response"].dictionary!
    for n in response
    {
    if n.key == "data"
    {
    Blog_Data = n.value.arrayValue
    }
    }
    print(Blog_Data)
    for i in Blog_Data
    {
    let Title = i["title"].stringValue
    print(Title)
        let Id = i["id"].int!
    let Category = i["category"].stringValue
    //description
    let Description = i["description"].stringValue
    let CreatedDate = i["createdDate"].stringValue
    let userData = i["user"].dictionary!
    var Email = ""
    var FirstName = ""
    var LastName = ""
    var Address = ""
    var Phone = ""
    for j in userData
    {
    if j.key == "email"
    {
    Email = j.value.stringValue
    }
    if j.key == "firstName"
    {
    FirstName = j.value.stringValue
    }
    if j.key == "lastName"
    {
    LastName = j.value.stringValue
    }
    if j.key == "address"
    {
    Address = j.value.stringValue
    }
    if j.key == "phone"
    {
    Phone = j.value.stringValue
    }
    }
arrOfBlogs.append(Get_Blogs(title: Title, category: Category, description: Description, createdDate: CreatedDate, ID:Id, email: Email, firstName: FirstName, lastName: LastName, address: Address, phone: Phone))
    }
    }
    print(arrOfBlogs)
    return arrOfBlogs
    }
}
